function login() {
  document.querySelector('.login-container').style.display = 'none';
  document.querySelector('.portfolio').classList.remove('hidden');
}

function hubungi() {
  alert("Terima kasih sudah mengunjungi portofolio saya 🙏");
}

function toggleTheme() {
  document.body.classList.toggle('dark');
}

